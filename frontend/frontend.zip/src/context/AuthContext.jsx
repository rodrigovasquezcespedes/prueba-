import { createContext, useState, useEffect } from 'react'
import axios from 'axios'

export const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState(null)

  const login = async (email, password) => {
    try {
      const response = await axios.post(
        'http://localhost:3000/api/users/login',
        {
          email,
          password
        },
        {
          withCredentials: true // Para enviar cookies
        }
      )
      setUser(response.data.user)
      setIsAuthenticated(true)
    } catch (error) {
      console.error('Error al iniciar sesión:', error)
    }
  }

  const logout = async () => {
    try {
      await axios.post(
        'http://localhost:3000/api/users/logout',
        {},
        { withCredentials: true }
      )
      setIsAuthenticated(false)
      setUser(null)
    } catch (error) {
      console.error('Error al cerrar sesión:', error)
    }
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}
