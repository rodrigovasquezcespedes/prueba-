const Favorites = () => {
  return <></>
}

export default Favorites
